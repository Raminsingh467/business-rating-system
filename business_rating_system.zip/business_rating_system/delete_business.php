<?php
include 'db.php';

$id = $_POST['id'];

$conn->query("DELETE FROM businesses WHERE id=$id");
?>
